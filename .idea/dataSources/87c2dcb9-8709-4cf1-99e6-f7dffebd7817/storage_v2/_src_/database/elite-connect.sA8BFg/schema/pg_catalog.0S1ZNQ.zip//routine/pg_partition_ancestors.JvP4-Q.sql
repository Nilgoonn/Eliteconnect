create function pg_partition_ancestors(partitionid regclass, OUT relid regclass) returns SETOF regclass
    language internal
as
$$ pg_partition_ancestors $$;

comment on function pg_partition_ancestors(regclass, out regclass) is 'view ancestors of the partition';

