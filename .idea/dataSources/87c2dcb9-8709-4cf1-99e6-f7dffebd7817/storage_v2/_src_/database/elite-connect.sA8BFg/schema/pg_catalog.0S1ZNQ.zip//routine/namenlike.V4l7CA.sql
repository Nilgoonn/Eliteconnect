create function namenlike(name, text) returns boolean
    language internal
as
$$ namenlike $$;

comment on function namenlike(name, text) is 'implementation of !~~ operator';

