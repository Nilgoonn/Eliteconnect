create function pg_is_in_recovery() returns boolean
    language internal
as
$$ pg_is_in_recovery $$;

comment on function pg_is_in_recovery() is 'true if server is in recovery';

