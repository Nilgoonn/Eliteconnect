create function path_mul_pt(path, point) returns path
    language internal
as
$$ path_mul_pt $$;

comment on function path_mul_pt(path, point) is 'implementation of * operator';

