create function pg_promote(wait boolean DEFAULT true, wait_seconds integer DEFAULT 60) returns boolean
    language internal
as
$$ pg_promote $$;

comment on function pg_promote(bool, int4) is 'promote standby server';

