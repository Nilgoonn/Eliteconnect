create function oidvectortypes(oidvector) returns text
    language internal
as
$$ oidvectortypes $$;

comment on function oidvectortypes(oidvector) is 'print type names of oidvector field';

