create function pg_event_trigger_ddl_commands(OUT classid oid, OUT objid oid, OUT objsubid integer, OUT command_tag text, OUT object_type text, OUT schema_name text, OUT object_identity text, OUT in_extension boolean, OUT command pg_ddl_command) returns SETOF record
    language internal
as
$$ pg_event_trigger_ddl_commands $$;

comment on function pg_event_trigger_ddl_commands(out oid, out oid, out int4, out text, out text, out text, out text, out bool, out pg_ddl_command) is 'list DDL actions being executed by the current command';

