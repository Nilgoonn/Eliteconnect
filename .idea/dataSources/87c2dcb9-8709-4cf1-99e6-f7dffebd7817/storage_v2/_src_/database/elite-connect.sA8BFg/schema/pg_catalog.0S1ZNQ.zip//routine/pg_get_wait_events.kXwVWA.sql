create function pg_get_wait_events(OUT type text, OUT name text, OUT description text) returns SETOF record
    language internal
as
$$ pg_get_wait_events $$;

comment on function pg_get_wait_events(out text, out text, out text) is 'describe wait events';

