create function pg_read_binary_file(text, bigint, bigint) returns bytea
    language internal
as
$$ pg_read_binary_file_off_len $$;

comment on function pg_read_binary_file(text) is 'read bytea from a file';

