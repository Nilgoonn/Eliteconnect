create function pg_get_statisticsobjdef_columns(oid) returns text
    language internal
as
$$ pg_get_statisticsobjdef_columns $$;

comment on function pg_get_statisticsobjdef_columns(oid) is 'extended statistics columns';

