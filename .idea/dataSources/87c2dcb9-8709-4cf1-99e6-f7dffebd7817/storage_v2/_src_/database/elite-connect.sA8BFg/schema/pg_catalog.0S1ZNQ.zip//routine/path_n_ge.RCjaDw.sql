create function path_n_ge(path, path) returns boolean
    language internal
as
$$ path_n_ge $$;

comment on function path_n_ge(path, path) is 'implementation of >= operator';

