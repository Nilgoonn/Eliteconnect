create function pg_node_tree_in(cstring) returns pg_node_tree
    language internal
as
$$ pg_node_tree_in $$;

comment on function pg_node_tree_in(cstring) is 'I/O';

