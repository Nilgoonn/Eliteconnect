create function oidvectoreq(oidvector, oidvector) returns boolean
    language internal
as
$$ oidvectoreq $$;

comment on function oidvectoreq(oidvector, oidvector) is 'implementation of = operator';

