create function numeric_recv(internal, oid, integer) returns numeric
    language internal
as
$$ numeric_recv $$;

comment on function numeric_recv(internal, oid, int4) is 'I/O';

