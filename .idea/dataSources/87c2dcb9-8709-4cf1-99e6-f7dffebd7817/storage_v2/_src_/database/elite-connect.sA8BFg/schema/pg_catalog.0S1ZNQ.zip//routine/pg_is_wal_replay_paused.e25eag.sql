create function pg_is_wal_replay_paused() returns boolean
    language internal
as
$$ pg_is_wal_replay_paused $$;

comment on function pg_is_wal_replay_paused() is 'true if wal replay is paused';

