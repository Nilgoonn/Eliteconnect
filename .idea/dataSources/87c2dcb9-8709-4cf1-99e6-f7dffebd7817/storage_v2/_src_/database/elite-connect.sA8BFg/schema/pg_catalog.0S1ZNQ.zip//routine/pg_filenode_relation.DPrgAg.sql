create function pg_filenode_relation(oid, oid) returns regclass
    language internal
as
$$ pg_filenode_relation $$;

comment on function pg_filenode_relation(oid, oid) is 'relation OID for filenode and tablespace';

