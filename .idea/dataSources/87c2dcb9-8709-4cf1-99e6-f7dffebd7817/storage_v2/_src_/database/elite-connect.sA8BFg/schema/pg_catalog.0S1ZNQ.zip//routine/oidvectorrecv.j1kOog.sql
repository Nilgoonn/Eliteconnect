create function oidvectorrecv(internal) returns oidvector
    language internal
as
$$ oidvectorrecv $$;

comment on function oidvectorrecv(internal) is 'I/O';

