create function multirange_agg_transfn(internal, anymultirange) returns internal
    language internal
as
$$ multirange_agg_transfn $$;

comment on function multirange_agg_transfn(internal, anymultirange) is 'aggregate transition function';

