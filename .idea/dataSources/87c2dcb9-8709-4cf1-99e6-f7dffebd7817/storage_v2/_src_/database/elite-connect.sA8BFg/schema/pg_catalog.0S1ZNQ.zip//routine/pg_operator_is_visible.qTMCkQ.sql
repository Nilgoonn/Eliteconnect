create function pg_operator_is_visible(oid) returns boolean
    language internal
as
$$ pg_operator_is_visible $$;

comment on function pg_operator_is_visible(oid) is 'is operator visible in search path?';

