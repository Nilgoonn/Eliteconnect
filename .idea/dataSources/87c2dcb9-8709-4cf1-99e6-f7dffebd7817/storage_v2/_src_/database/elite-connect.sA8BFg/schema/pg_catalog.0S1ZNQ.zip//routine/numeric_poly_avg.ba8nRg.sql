create function numeric_poly_avg(internal) returns numeric
    language internal
as
$$ numeric_poly_avg $$;

comment on function numeric_poly_avg(internal) is 'aggregate final function';

