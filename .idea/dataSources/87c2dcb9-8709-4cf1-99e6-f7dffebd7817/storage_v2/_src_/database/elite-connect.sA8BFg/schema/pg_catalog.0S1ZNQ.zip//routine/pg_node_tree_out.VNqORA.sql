create function pg_node_tree_out(pg_node_tree) returns cstring
    language internal
as
$$ pg_node_tree_out $$;

comment on function pg_node_tree_out(pg_node_tree) is 'I/O';

