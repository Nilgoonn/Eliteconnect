create function multirange_gt(anymultirange, anymultirange) returns boolean
    language internal
as
$$ multirange_gt $$;

comment on function multirange_gt(anymultirange, anymultirange) is 'implementation of > operator';

