create function pg_postmaster_start_time() returns timestamp with time zone
    language internal
as
$$ pg_postmaster_start_time $$;

comment on function pg_postmaster_start_time() is 'postmaster start time';

