create function numeric_avg_deserialize(bytea, internal) returns internal
    language internal
as
$$ numeric_avg_deserialize $$;

comment on function numeric_avg_deserialize(bytea, internal) is 'aggregate deserial function';

