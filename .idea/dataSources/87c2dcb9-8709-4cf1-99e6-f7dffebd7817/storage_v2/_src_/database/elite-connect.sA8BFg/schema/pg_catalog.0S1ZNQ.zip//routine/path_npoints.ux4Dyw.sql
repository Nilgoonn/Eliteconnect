create function path_npoints(path) returns integer
    language internal
as
$$ path_npoints $$;

comment on function path_npoints(path) is 'implementation of # operator';

