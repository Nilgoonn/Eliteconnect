create function network_ne(inet, inet) returns boolean
    language internal
as
$$ network_ne $$;

comment on function network_ne(inet, inet) is 'implementation of <> operator';

