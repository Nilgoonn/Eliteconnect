create function network_subset_support(internal) returns internal
    language internal
as
$$ network_subset_support $$;

comment on function network_subset_support(internal) is 'planner support for network_sub/superset';

