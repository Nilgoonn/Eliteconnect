create function pg_replication_origin_session_setup(text) returns void
    language internal
as
$$ pg_replication_origin_session_setup $$;

comment on function pg_replication_origin_session_setup(text) is 'configure session to maintain replication progress tracking for the passed in origin';

