create function multirange_gist_consistent(internal, anymultirange, smallint, oid, internal) returns boolean
    language internal
as
$$ multirange_gist_consistent $$;

comment on function multirange_gist_consistent(internal, anymultirange, int2, oid, internal) is 'GiST support';

