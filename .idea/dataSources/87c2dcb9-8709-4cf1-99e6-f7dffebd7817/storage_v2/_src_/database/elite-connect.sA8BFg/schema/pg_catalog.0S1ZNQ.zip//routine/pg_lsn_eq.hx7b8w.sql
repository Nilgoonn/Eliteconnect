create function pg_lsn_eq(pg_lsn, pg_lsn) returns boolean
    language internal
as
$$ pg_lsn_eq $$;

comment on function pg_lsn_eq(pg_lsn, pg_lsn) is 'implementation of = operator';

