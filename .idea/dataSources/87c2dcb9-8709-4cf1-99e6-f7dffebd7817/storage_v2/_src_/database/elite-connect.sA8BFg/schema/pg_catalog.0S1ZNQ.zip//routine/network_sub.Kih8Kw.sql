create function network_sub(inet, inet) returns boolean
    language internal
as
$$ network_sub $$;

comment on function network_sub(inet, inet) is 'implementation of << operator';

