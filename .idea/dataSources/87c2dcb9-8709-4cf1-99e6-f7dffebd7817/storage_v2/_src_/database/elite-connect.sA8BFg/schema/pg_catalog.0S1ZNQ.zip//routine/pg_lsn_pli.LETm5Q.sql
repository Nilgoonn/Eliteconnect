create function pg_lsn_pli(pg_lsn, numeric) returns pg_lsn
    language internal
as
$$ pg_lsn_pli $$;

comment on function pg_lsn_pli(pg_lsn, numeric) is 'implementation of + operator';

