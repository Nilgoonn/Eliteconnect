create function pg_node_tree_recv(internal) returns pg_node_tree
    language internal
as
$$ pg_node_tree_recv $$;

comment on function pg_node_tree_recv(internal) is 'I/O';

