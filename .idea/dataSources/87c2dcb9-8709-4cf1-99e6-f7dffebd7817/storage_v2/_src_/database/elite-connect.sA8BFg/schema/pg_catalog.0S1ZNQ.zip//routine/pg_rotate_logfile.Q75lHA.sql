create function pg_rotate_logfile() returns boolean
    language internal
as
$$ pg_rotate_logfile $$;

comment on function pg_rotate_logfile() is 'rotate log file';

