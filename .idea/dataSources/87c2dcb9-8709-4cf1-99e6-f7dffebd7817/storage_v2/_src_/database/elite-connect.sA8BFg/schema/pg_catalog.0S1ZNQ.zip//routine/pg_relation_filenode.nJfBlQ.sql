create function pg_relation_filenode(regclass) returns oid
    language internal
as
$$ pg_relation_filenode $$;

comment on function pg_relation_filenode(regclass) is 'filenode identifier of relation';

