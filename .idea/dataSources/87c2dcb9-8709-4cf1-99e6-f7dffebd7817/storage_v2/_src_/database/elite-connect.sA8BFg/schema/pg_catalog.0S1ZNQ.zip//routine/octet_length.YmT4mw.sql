create function octet_length(bytea) returns integer
    language internal
as
$$ byteaoctetlen $$;

comment on function octet_length(text) is 'octet length';

