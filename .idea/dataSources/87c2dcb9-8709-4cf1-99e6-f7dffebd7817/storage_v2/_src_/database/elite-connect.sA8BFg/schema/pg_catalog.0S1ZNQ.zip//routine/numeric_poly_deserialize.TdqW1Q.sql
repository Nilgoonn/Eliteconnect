create function numeric_poly_deserialize(bytea, internal) returns internal
    language internal
as
$$ numeric_poly_deserialize $$;

comment on function numeric_poly_deserialize(bytea, internal) is 'aggregate deserial function';

