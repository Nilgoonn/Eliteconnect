create function numeric_poly_serialize(internal) returns bytea
    language internal
as
$$ numeric_poly_serialize $$;

comment on function numeric_poly_serialize(internal) is 'aggregate serial function';

