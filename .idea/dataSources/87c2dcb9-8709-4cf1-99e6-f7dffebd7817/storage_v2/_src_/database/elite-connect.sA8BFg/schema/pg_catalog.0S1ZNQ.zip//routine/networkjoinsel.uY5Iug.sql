create function networkjoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$ networkjoinsel $$;

comment on function networkjoinsel(internal, oid, internal, int2, internal) is 'join selectivity for network operators';

