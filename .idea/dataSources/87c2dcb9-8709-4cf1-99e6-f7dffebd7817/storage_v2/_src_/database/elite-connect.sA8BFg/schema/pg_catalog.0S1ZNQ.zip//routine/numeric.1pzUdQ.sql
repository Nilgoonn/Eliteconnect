create function numeric(money) returns numeric
    language internal
as
$$ cash_numeric $$;

comment on function numeric(jsonb) is 'convert jsonb to numeric';

