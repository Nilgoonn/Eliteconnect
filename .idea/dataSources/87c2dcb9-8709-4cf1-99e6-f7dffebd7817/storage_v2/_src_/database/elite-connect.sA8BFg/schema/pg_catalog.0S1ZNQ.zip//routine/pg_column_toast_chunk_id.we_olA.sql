create function pg_column_toast_chunk_id("any") returns oid
    language internal
as
$$ pg_column_toast_chunk_id $$;

comment on function pg_column_toast_chunk_id(any) is 'chunk ID of on-disk TOASTed value';

