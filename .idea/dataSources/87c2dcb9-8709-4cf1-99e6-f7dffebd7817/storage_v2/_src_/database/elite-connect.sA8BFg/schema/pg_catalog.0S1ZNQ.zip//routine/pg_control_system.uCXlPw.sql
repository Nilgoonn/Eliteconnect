create function pg_control_system(OUT pg_control_version integer, OUT catalog_version_no integer, OUT system_identifier bigint, OUT pg_control_last_modified timestamp with time zone) returns record
    language internal
as
$$ pg_control_system $$;

comment on function pg_control_system(out int4, out int4, out int8, out timestamptz) is 'pg_controldata general state information as a function';

