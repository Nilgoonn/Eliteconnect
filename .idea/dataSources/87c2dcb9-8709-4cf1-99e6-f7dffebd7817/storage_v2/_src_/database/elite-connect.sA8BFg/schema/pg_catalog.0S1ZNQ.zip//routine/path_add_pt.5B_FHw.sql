create function path_add_pt(path, point) returns path
    language internal
as
$$ path_add_pt $$;

comment on function path_add_pt(path, point) is 'implementation of + operator';

