create function on_sl(lseg, line) returns boolean
    language internal
as
$$ on_sl $$;

comment on function on_sl(lseg, line) is 'implementation of <@ operator';

