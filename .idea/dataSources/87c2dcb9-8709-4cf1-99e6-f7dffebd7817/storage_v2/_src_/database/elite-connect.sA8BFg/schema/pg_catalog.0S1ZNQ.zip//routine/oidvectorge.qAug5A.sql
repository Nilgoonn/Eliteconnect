create function oidvectorge(oidvector, oidvector) returns boolean
    language internal
as
$$ oidvectorge $$;

comment on function oidvectorge(oidvector, oidvector) is 'implementation of >= operator';

