create function pg_logical_slot_peek_binary_changes(slot_name name, upto_lsn pg_lsn, upto_nchanges integer, VARIADIC options text[] DEFAULT '{}'::text[], OUT lsn pg_lsn, OUT xid xid, OUT data bytea) returns SETOF record
    language internal
as
$$ pg_logical_slot_peek_binary_changes $$;

comment on function pg_logical_slot_peek_binary_changes(name, pg_lsn, int4, _text, out pg_lsn, out xid, out bytea) is 'peek at binary changes from replication slot';

