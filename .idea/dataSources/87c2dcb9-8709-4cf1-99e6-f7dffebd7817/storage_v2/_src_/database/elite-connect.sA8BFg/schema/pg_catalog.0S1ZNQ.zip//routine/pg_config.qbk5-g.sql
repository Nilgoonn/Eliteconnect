create function pg_config(OUT name text, OUT setting text) returns SETOF record
    language internal
as
$$ pg_config $$;

comment on function pg_config(out text, out text) is 'pg_config binary as a function';

