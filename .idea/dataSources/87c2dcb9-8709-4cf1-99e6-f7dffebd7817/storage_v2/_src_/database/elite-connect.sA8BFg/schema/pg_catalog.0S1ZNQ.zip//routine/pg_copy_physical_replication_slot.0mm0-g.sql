create function pg_copy_physical_replication_slot(src_slot_name name, dst_slot_name name, OUT slot_name name, OUT lsn pg_lsn) returns record
    language internal
as
$$ pg_copy_physical_replication_slot_b $$;

comment on function pg_copy_physical_replication_slot(name, name, out name, out pg_lsn) is 'copy a physical replication slot';

