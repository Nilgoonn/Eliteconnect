create function pg_ls_waldir(OUT name text, OUT size bigint, OUT modification timestamp with time zone) returns SETOF record
    language internal
as
$$ pg_ls_waldir $$;

comment on function pg_ls_waldir(out text, out int8, out timestamptz) is 'list of files in the WAL directory';

