create function normalize(text, text DEFAULT 'NFC'::text) returns text
    language internal
as
$$ unicode_normalize_func $$;

comment on function normalize(text, text) is 'Unicode normalization';

