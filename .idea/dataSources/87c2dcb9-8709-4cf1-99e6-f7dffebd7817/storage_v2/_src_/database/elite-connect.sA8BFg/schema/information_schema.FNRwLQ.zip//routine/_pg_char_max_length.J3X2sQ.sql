create function _pg_char_max_length(typid oid, typmod integer) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

