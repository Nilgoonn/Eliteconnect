create function numeric_div(numeric, numeric) returns numeric
    language internal
as
$$ numeric_div $$;

comment on function numeric_div(numeric, numeric) is 'implementation of / operator';

