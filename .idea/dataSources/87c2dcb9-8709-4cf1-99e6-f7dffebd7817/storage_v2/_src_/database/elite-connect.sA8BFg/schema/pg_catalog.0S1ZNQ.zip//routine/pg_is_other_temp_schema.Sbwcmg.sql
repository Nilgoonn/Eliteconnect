create function pg_is_other_temp_schema(oid) returns boolean
    language internal
as
$$ pg_is_other_temp_schema $$;

comment on function pg_is_other_temp_schema(oid) is 'is schema another session''s temp schema?';

