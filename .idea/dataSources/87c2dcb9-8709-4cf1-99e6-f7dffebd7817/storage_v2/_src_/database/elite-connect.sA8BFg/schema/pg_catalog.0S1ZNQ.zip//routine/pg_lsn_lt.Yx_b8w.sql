create function pg_lsn_lt(pg_lsn, pg_lsn) returns boolean
    language internal
as
$$ pg_lsn_lt $$;

comment on function pg_lsn_lt(pg_lsn, pg_lsn) is 'implementation of < operator';

