create function pg_replication_origin_session_progress(boolean) returns pg_lsn
    language internal
as
$$ pg_replication_origin_session_progress $$;

comment on function pg_replication_origin_session_progress(bool) is 'get the replication progress of the current session';

