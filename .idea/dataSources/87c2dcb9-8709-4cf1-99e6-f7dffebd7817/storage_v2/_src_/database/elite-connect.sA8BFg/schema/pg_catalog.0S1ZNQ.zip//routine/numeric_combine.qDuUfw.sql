create function numeric_combine(internal, internal) returns internal
    language internal
as
$$ numeric_combine $$;

comment on function numeric_combine(internal, internal) is 'aggregate combine function';

