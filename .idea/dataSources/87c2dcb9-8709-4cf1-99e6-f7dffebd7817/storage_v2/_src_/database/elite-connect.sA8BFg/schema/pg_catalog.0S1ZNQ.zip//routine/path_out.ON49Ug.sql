create function path_out(path) returns cstring
    language internal
as
$$ path_out $$;

comment on function path_out(path) is 'I/O';

