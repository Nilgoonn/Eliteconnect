create function numeric_exp(numeric) returns numeric
    language internal
as
$$ numeric_exp $$;

comment on function numeric_exp(numeric) is 'natural exponential (e^x)';

