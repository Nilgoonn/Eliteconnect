create function pg_mcv_list_send(pg_mcv_list) returns bytea
    language internal
as
$$ pg_mcv_list_send $$;

comment on function pg_mcv_list_send(pg_mcv_list) is 'I/O';

