create function multirange_overlaps_multirange(anymultirange, anymultirange) returns boolean
    language internal
as
$$ multirange_overlaps_multirange $$;

comment on function multirange_overlaps_multirange(anymultirange, anymultirange) is 'implementation of && operator';

