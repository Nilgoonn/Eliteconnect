create function pg_replication_slot_advance(slot_name name, upto_lsn pg_lsn, OUT slot_name name, OUT end_lsn pg_lsn) returns record
    language internal
as
$$ pg_replication_slot_advance $$;

comment on function pg_replication_slot_advance(pg_lsn, out name, out pg_lsn) is 'advance logical replication slot';

