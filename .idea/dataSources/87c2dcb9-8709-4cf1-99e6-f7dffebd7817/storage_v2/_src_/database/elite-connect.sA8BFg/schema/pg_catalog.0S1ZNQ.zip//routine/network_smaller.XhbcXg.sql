create function network_smaller(inet, inet) returns inet
    language internal
as
$$ network_smaller $$;

comment on function network_smaller(inet, inet) is 'smaller of two';

