create function path(polygon) returns path
    language internal
as
$$ poly_path $$;

comment on function path(polygon) is 'convert polygon to path';

