create function pg_available_extension_versions(OUT name name, OUT version text, OUT superuser boolean, OUT trusted boolean, OUT relocatable boolean, OUT schema name, OUT requires name[], OUT comment text) returns SETOF record
    language internal
as
$$ pg_available_extension_versions $$;

comment on function pg_available_extension_versions(out name, out text, out bool, out bool, out bool, out name, out _name, out text) is 'list available extension versions';

