create function pg_opfamily_is_visible(oid) returns boolean
    language internal
as
$$ pg_opfamily_is_visible $$;

comment on function pg_opfamily_is_visible(oid) is 'is opfamily visible in search path?';

