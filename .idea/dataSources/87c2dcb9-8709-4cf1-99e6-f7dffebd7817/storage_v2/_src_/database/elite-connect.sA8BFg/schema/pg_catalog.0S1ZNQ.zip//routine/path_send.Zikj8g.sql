create function path_send(path) returns bytea
    language internal
as
$$ path_send $$;

comment on function path_send(path) is 'I/O';

