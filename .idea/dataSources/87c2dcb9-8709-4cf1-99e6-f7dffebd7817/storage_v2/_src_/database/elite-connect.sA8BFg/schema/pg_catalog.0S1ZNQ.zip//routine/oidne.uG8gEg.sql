create function oidne(oid, oid) returns boolean
    language internal
as
$$ oidne $$;

comment on function oidne(oid, oid) is 'implementation of <> operator';

