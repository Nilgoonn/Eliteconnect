create function pg_ndistinct_in(cstring) returns pg_ndistinct
    language internal
as
$$ pg_ndistinct_in $$;

comment on function pg_ndistinct_in(cstring) is 'I/O';

