create function path_inter(path, path) returns boolean
    language internal
as
$$ path_inter $$;

comment on function path_inter(path, path) is 'implementation of ?# operator';

