create function pg_replication_origin_progress(text, boolean) returns pg_lsn
    language internal
as
$$ pg_replication_origin_progress $$;

comment on function pg_replication_origin_progress(text, bool) is 'get an individual replication origin''s replication progress';

