create function pg_get_wal_replay_pause_state() returns text
    language internal
as
$$ pg_get_wal_replay_pause_state $$;

comment on function pg_get_wal_replay_pause_state() is 'get wal replay pause state';

