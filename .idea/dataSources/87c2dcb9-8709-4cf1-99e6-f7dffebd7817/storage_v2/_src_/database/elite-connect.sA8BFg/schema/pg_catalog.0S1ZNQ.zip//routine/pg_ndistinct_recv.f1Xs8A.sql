create function pg_ndistinct_recv(internal) returns pg_ndistinct
    language internal
as
$$ pg_ndistinct_recv $$;

comment on function pg_ndistinct_recv(internal) is 'I/O';

