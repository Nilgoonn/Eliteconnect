create function multirange_overlaps_range(anymultirange, anyrange) returns boolean
    language internal
as
$$ multirange_overlaps_range $$;

comment on function multirange_overlaps_range(anymultirange, anyrange) is 'implementation of && operator';

