create function pg_relation_is_updatable(regclass, boolean) returns integer
    language internal
as
$$ pg_relation_is_updatable $$;

comment on function pg_relation_is_updatable(regclass, bool) is 'is a relation insertable/updatable/deletable';

