create function pg_current_snapshot() returns pg_snapshot
    language internal
as
$$ pg_current_snapshot $$;

comment on function pg_current_snapshot() is 'get current snapshot';

