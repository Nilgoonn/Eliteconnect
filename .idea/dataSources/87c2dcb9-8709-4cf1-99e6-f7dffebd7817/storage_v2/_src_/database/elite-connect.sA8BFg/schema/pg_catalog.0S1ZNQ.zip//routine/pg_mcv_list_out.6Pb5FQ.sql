create function pg_mcv_list_out(pg_mcv_list) returns cstring
    language internal
as
$$ pg_mcv_list_out $$;

comment on function pg_mcv_list_out(pg_mcv_list) is 'I/O';

