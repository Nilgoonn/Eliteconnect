create function pg_notify(text, text) returns void
    language internal
as
$$ pg_notify $$;

comment on function pg_notify(text, text) is 'send a notification event';

