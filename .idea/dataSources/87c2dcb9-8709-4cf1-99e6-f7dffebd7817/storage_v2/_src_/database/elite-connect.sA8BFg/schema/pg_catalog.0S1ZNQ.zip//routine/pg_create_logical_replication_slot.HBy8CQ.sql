create function pg_create_logical_replication_slot(slot_name name, plugin name, temporary boolean DEFAULT false, twophase boolean DEFAULT false, failover boolean DEFAULT false, OUT slot_name name, OUT lsn pg_lsn) returns record
    language internal
as
$$ pg_create_logical_replication_slot $$;

comment on function pg_create_logical_replication_slot(name, bool, bool, bool, out name, out pg_lsn) is 'set up a logical replication slot';

