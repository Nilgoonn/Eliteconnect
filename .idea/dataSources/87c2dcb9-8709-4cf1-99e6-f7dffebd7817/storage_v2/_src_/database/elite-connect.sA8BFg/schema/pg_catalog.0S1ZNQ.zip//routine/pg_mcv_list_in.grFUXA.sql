create function pg_mcv_list_in(cstring) returns pg_mcv_list
    language internal
as
$$ pg_mcv_list_in $$;

comment on function pg_mcv_list_in(cstring) is 'I/O';

