create function multirange_minus(anymultirange, anymultirange) returns anymultirange
    language internal
as
$$ multirange_minus $$;

comment on function multirange_minus(anymultirange, anymultirange) is 'implementation of - operator';

