create function network_le(inet, inet) returns boolean
    language internal
as
$$ network_le $$;

comment on function network_le(inet, inet) is 'implementation of <= operator';

