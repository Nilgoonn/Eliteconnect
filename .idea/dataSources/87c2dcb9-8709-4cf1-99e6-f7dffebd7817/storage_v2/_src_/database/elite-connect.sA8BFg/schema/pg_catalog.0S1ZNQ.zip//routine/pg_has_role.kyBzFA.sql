create function pg_has_role(name, name, text) returns boolean
    language internal
as
$$ pg_has_role_name_name $$;

comment on function pg_has_role(oid, oid, text) is 'user privilege on role by user oid, role oid';

