create function pg_current_xact_id() returns xid8
    language internal
as
$$ pg_current_xact_id $$;

comment on function pg_current_xact_id() is 'get current transaction ID';

