create function numeric_poly_var_pop(internal) returns numeric
    language internal
as
$$ numeric_poly_var_pop $$;

comment on function numeric_poly_var_pop(internal) is 'aggregate final function';

