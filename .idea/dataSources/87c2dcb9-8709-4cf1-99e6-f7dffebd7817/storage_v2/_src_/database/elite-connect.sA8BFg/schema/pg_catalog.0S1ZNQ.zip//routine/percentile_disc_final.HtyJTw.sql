create function percentile_disc_final(internal, double precision, anyelement) returns anyelement
    language internal
as
$$ percentile_disc_final $$;

comment on function percentile_disc_final(internal, float8, anyelement) is 'aggregate final function';

