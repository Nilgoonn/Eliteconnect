create function pg_replication_origin_create(text) returns oid
    language internal
as
$$ pg_replication_origin_create $$;

comment on function pg_replication_origin_create(text) is 'create a replication origin';

