create function pg_partition_root(regclass) returns regclass
    language internal
as
$$ pg_partition_root $$;

comment on function pg_partition_root(regclass) is 'get top-most partition root parent';

