create function percentile_disc_multi_final(internal, double precision[], anyelement) returns anyarray
    language internal
as
$$ percentile_disc_multi_final $$;

comment on function percentile_disc_multi_final(internal, _float8, anyelement) is 'aggregate final function';

