create function pg_get_shmem_allocations(OUT name text, OUT off bigint, OUT size bigint, OUT allocated_size bigint) returns SETOF record
    language internal
as
$$ pg_get_shmem_allocations $$;

comment on function pg_get_shmem_allocations(out text, out int8, out int8, out int8) is 'allocations from the main shared memory segment';

