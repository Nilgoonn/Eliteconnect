create function numeric_ne(numeric, numeric) returns boolean
    language internal
as
$$ numeric_ne $$;

comment on function numeric_ne(numeric, numeric) is 'implementation of <> operator';

