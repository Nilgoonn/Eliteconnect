create function namelike(name, text) returns boolean
    language internal
as
$$ namelike $$;

comment on function namelike(name, text) is 'implementation of ~~ operator';

