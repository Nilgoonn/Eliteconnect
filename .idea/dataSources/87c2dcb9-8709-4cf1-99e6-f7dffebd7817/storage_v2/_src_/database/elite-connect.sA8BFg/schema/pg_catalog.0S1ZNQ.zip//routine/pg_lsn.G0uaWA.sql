create function pg_lsn(numeric) returns pg_lsn
    language internal
as
$$ numeric_pg_lsn $$;

comment on function pg_lsn(numeric) is 'convert numeric to pg_lsn';

