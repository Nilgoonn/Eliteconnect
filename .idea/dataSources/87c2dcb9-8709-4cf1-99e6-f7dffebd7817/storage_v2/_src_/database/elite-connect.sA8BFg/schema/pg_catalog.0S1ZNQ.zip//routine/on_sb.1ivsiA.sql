create function on_sb(lseg, box) returns boolean
    language internal
as
$$ on_sb $$;

comment on function on_sb(lseg, box) is 'implementation of <@ operator';

