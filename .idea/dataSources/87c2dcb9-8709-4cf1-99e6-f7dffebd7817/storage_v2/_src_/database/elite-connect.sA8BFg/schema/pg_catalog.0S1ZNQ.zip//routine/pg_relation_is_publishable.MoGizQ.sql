create function pg_relation_is_publishable(regclass) returns boolean
    language internal
as
$$ pg_relation_is_publishable $$;

comment on function pg_relation_is_publishable(regclass) is 'returns whether a relation can be part of a publication';

