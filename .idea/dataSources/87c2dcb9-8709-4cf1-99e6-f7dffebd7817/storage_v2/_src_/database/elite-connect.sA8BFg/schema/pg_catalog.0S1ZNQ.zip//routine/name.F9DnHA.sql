create function name(text) returns name
    language internal
as
$$ text_name $$;

comment on function name(varchar) is 'convert varchar to name';

