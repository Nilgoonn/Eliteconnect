create function numeric_support(internal) returns internal
    language internal
as
$$ numeric_support $$;

comment on function numeric_support(internal) is 'planner support for numeric length coercion';

