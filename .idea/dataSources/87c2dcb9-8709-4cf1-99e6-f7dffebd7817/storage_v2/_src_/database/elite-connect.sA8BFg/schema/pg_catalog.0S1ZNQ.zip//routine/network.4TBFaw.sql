create function network(inet) returns cidr
    language internal
as
$$ network_network $$;

comment on function network(inet) is 'network part of address';

