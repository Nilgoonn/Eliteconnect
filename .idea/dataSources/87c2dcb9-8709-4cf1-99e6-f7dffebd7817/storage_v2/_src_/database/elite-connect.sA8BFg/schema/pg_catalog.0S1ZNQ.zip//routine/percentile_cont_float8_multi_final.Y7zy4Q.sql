create function percentile_cont_float8_multi_final(internal, double precision[]) returns double precision[]
    language internal
as
$$ percentile_cont_float8_multi_final $$;

comment on function percentile_cont_float8_multi_final(internal, _float8) is 'aggregate final function';

