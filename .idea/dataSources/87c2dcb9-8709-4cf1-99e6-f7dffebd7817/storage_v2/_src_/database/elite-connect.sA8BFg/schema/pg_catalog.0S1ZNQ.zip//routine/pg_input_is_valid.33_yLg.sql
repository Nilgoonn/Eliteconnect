create function pg_input_is_valid(text, text) returns boolean
    language internal
as
$$ pg_input_is_valid $$;

comment on function pg_input_is_valid(text, text) is 'test whether string is valid input for data type';

