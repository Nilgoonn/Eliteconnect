create function pg_input_error_info(value text, type_name text, OUT message text, OUT detail text, OUT hint text, OUT sql_error_code text) returns record
    language internal
as
$$ pg_input_error_info $$;

comment on function pg_input_error_info(text, text, out text, out text, out text, out text) is 'get error details if string is not valid input for data type';

