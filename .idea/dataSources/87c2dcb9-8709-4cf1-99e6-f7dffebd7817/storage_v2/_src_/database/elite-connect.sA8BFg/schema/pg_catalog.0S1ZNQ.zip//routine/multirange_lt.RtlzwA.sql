create function multirange_lt(anymultirange, anymultirange) returns boolean
    language internal
as
$$ multirange_lt $$;

comment on function multirange_lt(anymultirange, anymultirange) is 'implementation of < operator';

