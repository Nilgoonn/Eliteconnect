create function pg_prepared_xact(OUT transaction xid, OUT gid text, OUT prepared timestamp with time zone, OUT ownerid oid, OUT dbid oid) returns SETOF record
    language internal
as
$$ pg_prepared_xact $$;

comment on function pg_prepared_xact(out xid, out text, out timestamptz, out oid, out oid) is 'view two-phase transactions';

