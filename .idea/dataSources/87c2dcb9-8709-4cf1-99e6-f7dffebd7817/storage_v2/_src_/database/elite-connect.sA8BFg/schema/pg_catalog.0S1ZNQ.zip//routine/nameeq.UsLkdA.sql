create function nameeq(name, name) returns boolean
    language internal
as
$$ nameeq $$;

comment on function nameeq(name, name) is 'implementation of = operator';

