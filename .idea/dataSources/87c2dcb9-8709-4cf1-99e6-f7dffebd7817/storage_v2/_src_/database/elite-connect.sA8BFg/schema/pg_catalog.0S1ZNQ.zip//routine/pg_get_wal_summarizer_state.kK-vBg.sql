create function pg_get_wal_summarizer_state(OUT summarized_tli bigint, OUT summarized_lsn pg_lsn, OUT pending_lsn pg_lsn, OUT summarizer_pid integer) returns record
    language internal
as
$$ pg_get_wal_summarizer_state $$;

comment on function pg_get_wal_summarizer_state(out int8, out pg_lsn, out pg_lsn, out int4) is 'WAL summarizer state';

