create function _pg_expandarray(anyarray, OUT x anyelement, OUT n integer) returns SETOF record
    language sql
as
$$
SELECT * FROM pg_catalog.unnest($1) WITH ORDINALITY
$$;

