create function pg_identify_object_as_address(classid oid, objid oid, objsubid integer, OUT type text, OUT object_names text[], OUT object_args text[]) returns record
    language internal
as
$$ pg_identify_object_as_address $$;

comment on function pg_identify_object_as_address(oid, oid, int4, out text, out _text, out _text) is 'get identification of SQL object for pg_get_object_address()';

