create function pg_collation_actual_version(oid) returns text
    language internal
as
$$ pg_collation_actual_version $$;

comment on function pg_collation_actual_version(oid) is 'get actual version of collation from operating system';

