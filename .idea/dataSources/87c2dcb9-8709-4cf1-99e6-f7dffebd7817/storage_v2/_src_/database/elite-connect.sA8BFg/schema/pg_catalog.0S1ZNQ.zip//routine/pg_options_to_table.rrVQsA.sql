create function pg_options_to_table(options_array text[], OUT option_name text, OUT option_value text) returns SETOF record
    language internal
as
$$ pg_options_to_table $$;

comment on function pg_options_to_table(_text, out text, out text) is 'convert generic options array to name/value table';

