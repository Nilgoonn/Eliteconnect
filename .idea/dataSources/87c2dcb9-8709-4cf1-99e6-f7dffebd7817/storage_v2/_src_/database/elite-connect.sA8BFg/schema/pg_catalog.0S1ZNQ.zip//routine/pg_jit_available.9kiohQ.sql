create function pg_jit_available() returns boolean
    language internal
as
$$ pg_jit_available $$;

comment on function pg_jit_available() is 'Is JIT compilation available in this session?';

