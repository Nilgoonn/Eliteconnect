create function oidlt(oid, oid) returns boolean
    language internal
as
$$ oidlt $$;

comment on function oidlt(oid, oid) is 'implementation of < operator';

