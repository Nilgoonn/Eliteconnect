create function pg_replication_origin_xact_setup(pg_lsn, timestamp with time zone) returns void
    language internal
as
$$ pg_replication_origin_xact_setup $$;

comment on function pg_replication_origin_xact_setup(pg_lsn, timestamptz) is 'setup the transaction''s origin lsn and timestamp';

