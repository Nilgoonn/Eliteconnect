create function oidvectorsend(oidvector) returns bytea
    language internal
as
$$ oidvectorsend $$;

comment on function oidvectorsend(oidvector) is 'I/O';

