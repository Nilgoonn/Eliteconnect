create function _pg_index_position(oid, smallint) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

