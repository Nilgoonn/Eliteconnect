create function pg_dependencies_in(cstring) returns pg_dependencies
    language internal
as
$$ pg_dependencies_in $$;

comment on function pg_dependencies_in(cstring) is 'I/O';

