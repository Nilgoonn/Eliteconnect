create function pg_advisory_unlock(bigint) returns boolean
    language internal
as
$$ pg_advisory_unlock_int8 $$;

comment on function pg_advisory_unlock(int4, int4) is 'release exclusive advisory lock';

