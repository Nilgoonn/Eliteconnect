create function pg_replication_origin_oid(text) returns oid
    language internal
as
$$ pg_replication_origin_oid $$;

comment on function pg_replication_origin_oid(text) is 'translate the replication origin''s name to its id';

