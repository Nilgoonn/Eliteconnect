create function numnode(tsquery) returns integer
    language internal
as
$$ tsquery_numnode $$;

comment on function numnode(tsquery) is 'number of nodes';

