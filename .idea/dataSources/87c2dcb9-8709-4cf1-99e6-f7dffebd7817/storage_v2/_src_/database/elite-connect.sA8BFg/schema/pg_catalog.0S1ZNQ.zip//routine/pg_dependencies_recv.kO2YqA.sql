create function pg_dependencies_recv(internal) returns pg_dependencies
    language internal
as
$$ pg_dependencies_recv $$;

comment on function pg_dependencies_recv(internal) is 'I/O';

