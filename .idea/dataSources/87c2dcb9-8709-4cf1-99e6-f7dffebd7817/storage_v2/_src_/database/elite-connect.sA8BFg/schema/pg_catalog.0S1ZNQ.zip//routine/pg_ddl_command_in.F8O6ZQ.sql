create function pg_ddl_command_in(cstring) returns pg_ddl_command
    language internal
as
$$ pg_ddl_command_in $$;

comment on function pg_ddl_command_in(cstring) is 'I/O';

