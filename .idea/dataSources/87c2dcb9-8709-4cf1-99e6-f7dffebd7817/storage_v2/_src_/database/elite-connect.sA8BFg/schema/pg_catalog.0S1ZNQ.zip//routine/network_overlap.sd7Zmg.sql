create function network_overlap(inet, inet) returns boolean
    language internal
as
$$ network_overlap $$;

comment on function network_overlap(inet, inet) is 'implementation of && operator';

