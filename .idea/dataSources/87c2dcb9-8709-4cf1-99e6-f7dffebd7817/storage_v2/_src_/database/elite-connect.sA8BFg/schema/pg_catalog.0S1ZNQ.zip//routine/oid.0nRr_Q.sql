create function oid(bigint) returns oid
    language internal
as
$$ i8tooid $$;

comment on function oid(int8) is 'convert int8 to oid';

