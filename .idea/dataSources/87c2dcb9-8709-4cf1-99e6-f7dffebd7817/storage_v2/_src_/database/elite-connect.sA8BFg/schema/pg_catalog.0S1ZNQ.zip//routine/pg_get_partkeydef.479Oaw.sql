create function pg_get_partkeydef(oid) returns text
    language internal
as
$$ pg_get_partkeydef $$;

comment on function pg_get_partkeydef(oid) is 'partition key description';

