create function pg_logical_slot_get_changes(slot_name name, upto_lsn pg_lsn, upto_nchanges integer, VARIADIC options text[] DEFAULT '{}'::text[], OUT lsn pg_lsn, OUT xid xid, OUT data text) returns SETOF record
    language internal
as
$$ pg_logical_slot_get_changes $$;

comment on function pg_logical_slot_get_changes(name, pg_lsn, int4, _text, out pg_lsn, out xid, out text) is 'get changes from replication slot';

