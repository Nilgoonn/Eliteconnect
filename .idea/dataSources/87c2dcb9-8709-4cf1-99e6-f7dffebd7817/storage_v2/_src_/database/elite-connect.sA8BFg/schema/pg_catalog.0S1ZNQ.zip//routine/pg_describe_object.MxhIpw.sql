create function pg_describe_object(oid, oid, integer) returns text
    language internal
as
$$ pg_describe_object $$;

comment on function pg_describe_object(oid, oid, int4) is 'get identification of SQL object';

