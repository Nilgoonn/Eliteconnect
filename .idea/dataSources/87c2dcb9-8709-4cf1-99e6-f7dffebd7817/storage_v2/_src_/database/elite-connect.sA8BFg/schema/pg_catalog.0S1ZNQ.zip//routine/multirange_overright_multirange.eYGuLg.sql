create function multirange_overright_multirange(anymultirange, anymultirange) returns boolean
    language internal
as
$$ multirange_overright_multirange $$;

comment on function multirange_overright_multirange(anymultirange, anymultirange) is 'implementation of &> operator';

