create function pg_cancel_backend(integer) returns boolean
    language internal
as
$$ pg_cancel_backend $$;

comment on function pg_cancel_backend(int4) is 'cancel a server process'' current query';

