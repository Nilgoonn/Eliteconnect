create function path_in(cstring) returns path
    language internal
as
$$ path_in $$;

comment on function path_in(cstring) is 'I/O';

