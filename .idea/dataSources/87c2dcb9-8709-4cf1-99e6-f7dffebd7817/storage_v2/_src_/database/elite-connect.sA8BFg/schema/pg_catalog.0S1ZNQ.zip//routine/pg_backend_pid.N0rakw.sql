create function pg_backend_pid() returns integer
    language internal
as
$$ pg_backend_pid $$;

comment on function pg_backend_pid() is 'statistics: current backend PID';

