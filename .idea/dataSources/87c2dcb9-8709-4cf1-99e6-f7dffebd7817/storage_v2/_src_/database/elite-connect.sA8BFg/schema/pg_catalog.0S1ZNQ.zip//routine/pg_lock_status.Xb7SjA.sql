create function pg_lock_status(OUT locktype text, OUT database oid, OUT relation oid, OUT page integer, OUT tuple smallint, OUT virtualxid text, OUT transactionid xid, OUT classid oid, OUT objid oid, OUT objsubid smallint, OUT virtualtransaction text, OUT pid integer, OUT mode text, OUT granted boolean, OUT fastpath boolean, OUT waitstart timestamp with time zone) returns SETOF record
    language internal
as
$$ pg_lock_status $$;

comment on function pg_lock_status(out text, out oid, out oid, out int4, out int2, out text, out xid, out oid, out oid, out int2, out text, out int4, out text, out bool, out bool, out timestamptz) is 'view system lock information';

