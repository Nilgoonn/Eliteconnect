create function multirange_agg_finalfn(internal, anymultirange) returns anymultirange
    language internal
as
$$ range_agg_finalfn $$;

comment on function multirange_agg_finalfn(internal, anymultirange) is 'aggregate final function';

