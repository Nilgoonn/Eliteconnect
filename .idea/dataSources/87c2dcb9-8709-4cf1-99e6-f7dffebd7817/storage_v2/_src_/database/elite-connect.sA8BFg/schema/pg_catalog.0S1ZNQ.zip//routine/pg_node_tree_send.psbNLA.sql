create function pg_node_tree_send(pg_node_tree) returns bytea
    language internal
as
$$ pg_node_tree_send $$;

comment on function pg_node_tree_send(pg_node_tree) is 'I/O';

