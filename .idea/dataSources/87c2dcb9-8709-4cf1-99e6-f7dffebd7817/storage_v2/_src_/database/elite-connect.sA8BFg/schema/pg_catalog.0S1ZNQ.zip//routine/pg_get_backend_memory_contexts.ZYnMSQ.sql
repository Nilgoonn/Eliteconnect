create function pg_get_backend_memory_contexts(OUT name text, OUT ident text, OUT parent text, OUT level integer, OUT total_bytes bigint, OUT total_nblocks bigint, OUT free_bytes bigint, OUT free_chunks bigint, OUT used_bytes bigint) returns SETOF record
    language internal
as
$$ pg_get_backend_memory_contexts $$;

comment on function pg_get_backend_memory_contexts(out text, out text, out text, out int4, out int8, out int8, out int8, out int8, out int8) is 'information about all memory contexts of local backend';

