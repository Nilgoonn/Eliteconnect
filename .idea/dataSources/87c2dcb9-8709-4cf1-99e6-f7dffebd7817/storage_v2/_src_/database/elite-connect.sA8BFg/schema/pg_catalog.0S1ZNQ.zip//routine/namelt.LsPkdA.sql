create function namelt(name, name) returns boolean
    language internal
as
$$ namelt $$;

comment on function namelt(name, name) is 'implementation of < operator';

