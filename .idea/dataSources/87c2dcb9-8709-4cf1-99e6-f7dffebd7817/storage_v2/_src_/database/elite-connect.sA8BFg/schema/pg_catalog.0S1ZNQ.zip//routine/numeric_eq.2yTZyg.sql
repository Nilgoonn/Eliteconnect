create function numeric_eq(numeric, numeric) returns boolean
    language internal
as
$$ numeric_eq $$;

comment on function numeric_eq(numeric, numeric) is 'implementation of = operator';

