create function pg_lsn_gt(pg_lsn, pg_lsn) returns boolean
    language internal
as
$$ pg_lsn_gt $$;

comment on function pg_lsn_gt(pg_lsn, pg_lsn) is 'implementation of > operator';

