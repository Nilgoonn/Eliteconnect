create function path_sub_pt(path, point) returns path
    language internal
as
$$ path_sub_pt $$;

comment on function path_sub_pt(path, point) is 'implementation of - operator';

