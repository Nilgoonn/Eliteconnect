create function network_supeq(inet, inet) returns boolean
    language internal
as
$$ network_supeq $$;

comment on function network_supeq(inet, inet) is 'implementation of >>= operator';

