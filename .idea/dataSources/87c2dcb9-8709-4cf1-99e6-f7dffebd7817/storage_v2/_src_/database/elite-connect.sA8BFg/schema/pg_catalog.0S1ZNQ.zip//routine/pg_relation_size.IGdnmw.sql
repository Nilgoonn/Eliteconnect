create function pg_relation_size(regclass) returns bigint
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function pg_relation_size(regclass, text) is 'disk space usage for the specified fork of a table or index';

