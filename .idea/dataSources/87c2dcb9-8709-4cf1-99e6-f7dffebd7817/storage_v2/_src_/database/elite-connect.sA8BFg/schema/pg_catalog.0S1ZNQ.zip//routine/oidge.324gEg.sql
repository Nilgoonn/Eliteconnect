create function oidge(oid, oid) returns boolean
    language internal
as
$$ oidge $$;

comment on function oidge(oid, oid) is 'implementation of >= operator';

