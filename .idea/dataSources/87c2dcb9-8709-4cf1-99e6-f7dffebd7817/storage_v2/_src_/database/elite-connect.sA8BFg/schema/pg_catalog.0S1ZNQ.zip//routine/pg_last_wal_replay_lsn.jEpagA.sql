create function pg_last_wal_replay_lsn() returns pg_lsn
    language internal
as
$$ pg_last_wal_replay_lsn $$;

comment on function pg_last_wal_replay_lsn() is 'last wal replay location';

