create function pg_get_userbyid(oid) returns name
    language internal
as
$$ pg_get_userbyid $$;

comment on function pg_get_userbyid(oid) is 'role name by OID (with fallback)';

