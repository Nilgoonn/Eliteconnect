create function multirange_recv(internal, oid, integer) returns anymultirange
    language internal
as
$$ multirange_recv $$;

comment on function multirange_recv(internal, oid, int4) is 'I/O';

