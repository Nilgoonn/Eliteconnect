create function pg_lsn_recv(internal) returns pg_lsn
    language internal
as
$$ pg_lsn_recv $$;

comment on function pg_lsn_recv(internal) is 'I/O';

