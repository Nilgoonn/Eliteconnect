create function pg_lsn_mi(pg_lsn, pg_lsn) returns numeric
    language internal
as
$$ pg_lsn_mi $$;

comment on function pg_lsn_mi(pg_lsn, pg_lsn) is 'implementation of - operator';

