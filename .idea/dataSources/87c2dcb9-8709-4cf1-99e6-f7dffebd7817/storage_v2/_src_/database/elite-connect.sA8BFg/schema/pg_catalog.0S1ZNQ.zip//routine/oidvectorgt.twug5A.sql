create function oidvectorgt(oidvector, oidvector) returns boolean
    language internal
as
$$ oidvectorgt $$;

comment on function oidvectorgt(oidvector, oidvector) is 'implementation of > operator';

