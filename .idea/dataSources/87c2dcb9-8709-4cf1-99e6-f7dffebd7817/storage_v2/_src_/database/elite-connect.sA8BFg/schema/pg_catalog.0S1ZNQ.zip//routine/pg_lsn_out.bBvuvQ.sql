create function pg_lsn_out(pg_lsn) returns cstring
    language internal
as
$$ pg_lsn_out $$;

comment on function pg_lsn_out(pg_lsn) is 'I/O';

