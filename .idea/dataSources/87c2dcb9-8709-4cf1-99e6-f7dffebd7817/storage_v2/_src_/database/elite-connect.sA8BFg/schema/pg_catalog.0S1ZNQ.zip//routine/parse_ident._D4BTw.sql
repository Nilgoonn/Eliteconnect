create function parse_ident(str text, strict boolean DEFAULT true) returns text[]
    language internal
as
$$ parse_ident $$;

comment on function parse_ident(text, bool) is 'parse qualified identifier to array of identifiers';

