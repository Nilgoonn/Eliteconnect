create function numeric_poly_var_samp(internal) returns numeric
    language internal
as
$$ numeric_poly_var_samp $$;

comment on function numeric_poly_var_samp(internal) is 'aggregate final function';

