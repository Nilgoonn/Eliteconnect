create function pg_lsn_larger(pg_lsn, pg_lsn) returns pg_lsn
    language internal
as
$$ pg_lsn_larger $$;

comment on function pg_lsn_larger(pg_lsn, pg_lsn) is 'larger of two';

