create function numeric_abs(numeric) returns numeric
    language internal
as
$$ numeric_abs $$;

comment on function numeric_abs(numeric) is 'implementation of @ operator';

