create function pg_lsn_smaller(pg_lsn, pg_lsn) returns pg_lsn
    language internal
as
$$ pg_lsn_smaller $$;

comment on function pg_lsn_smaller(pg_lsn, pg_lsn) is 'smaller of two';

