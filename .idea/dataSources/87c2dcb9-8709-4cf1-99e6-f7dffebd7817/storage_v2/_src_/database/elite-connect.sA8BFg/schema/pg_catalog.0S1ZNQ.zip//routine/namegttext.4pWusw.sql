create function namegttext(name, text) returns boolean
    language internal
as
$$ namegttext $$;

comment on function namegttext(name, text) is 'implementation of > operator';

