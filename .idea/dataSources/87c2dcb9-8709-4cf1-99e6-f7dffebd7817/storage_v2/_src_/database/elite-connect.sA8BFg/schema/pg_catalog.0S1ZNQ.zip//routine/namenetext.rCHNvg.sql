create function namenetext(name, text) returns boolean
    language internal
as
$$ namenetext $$;

comment on function namenetext(name, text) is 'implementation of <> operator';

