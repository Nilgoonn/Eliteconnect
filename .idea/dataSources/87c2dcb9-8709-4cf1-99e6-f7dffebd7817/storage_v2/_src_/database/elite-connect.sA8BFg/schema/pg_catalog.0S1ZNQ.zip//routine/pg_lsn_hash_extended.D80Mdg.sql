create function pg_lsn_hash_extended(pg_lsn, bigint) returns bigint
    language internal
as
$$ pg_lsn_hash_extended $$;

comment on function pg_lsn_hash_extended(pg_lsn, int8) is 'hash';

