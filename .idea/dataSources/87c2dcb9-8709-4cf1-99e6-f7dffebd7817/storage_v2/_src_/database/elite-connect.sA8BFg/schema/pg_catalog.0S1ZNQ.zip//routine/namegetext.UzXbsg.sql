create function namegetext(name, text) returns boolean
    language internal
as
$$ namegetext $$;

comment on function namegetext(name, text) is 'implementation of >= operator';

