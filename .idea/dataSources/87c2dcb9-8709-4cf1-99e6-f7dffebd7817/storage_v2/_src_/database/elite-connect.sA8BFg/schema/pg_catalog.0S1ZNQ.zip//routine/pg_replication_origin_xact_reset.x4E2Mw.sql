create function pg_replication_origin_xact_reset() returns void
    language internal
as
$$ pg_replication_origin_xact_reset $$;

comment on function pg_replication_origin_xact_reset() is 'reset the transaction''s origin lsn and timestamp';

