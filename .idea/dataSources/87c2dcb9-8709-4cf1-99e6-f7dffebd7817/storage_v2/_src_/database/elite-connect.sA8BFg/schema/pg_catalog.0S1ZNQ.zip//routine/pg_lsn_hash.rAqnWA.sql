create function pg_lsn_hash(pg_lsn) returns integer
    language internal
as
$$ pg_lsn_hash $$;

comment on function pg_lsn_hash(pg_lsn) is 'hash';

