create function pg_get_replica_identity_index(regclass) returns regclass
    language internal
as
$$ pg_get_replica_identity_index $$;

comment on function pg_get_replica_identity_index(regclass) is 'oid of replica identity index if any';

