create function pg_available_wal_summaries(OUT tli bigint, OUT start_lsn pg_lsn, OUT end_lsn pg_lsn) returns SETOF record
    language internal
as
$$ pg_available_wal_summaries $$;

comment on function pg_available_wal_summaries(out int8, out pg_lsn, out pg_lsn) is 'list of available WAL summary files';

