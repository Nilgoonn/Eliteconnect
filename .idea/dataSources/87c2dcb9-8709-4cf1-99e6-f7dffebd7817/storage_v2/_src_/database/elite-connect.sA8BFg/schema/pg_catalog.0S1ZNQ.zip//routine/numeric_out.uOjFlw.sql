create function numeric_out(numeric) returns cstring
    language internal
as
$$ numeric_out $$;

comment on function numeric_out(numeric) is 'I/O';

