create function pg_dependencies_out(pg_dependencies) returns cstring
    language internal
as
$$ pg_dependencies_out $$;

comment on function pg_dependencies_out(pg_dependencies) is 'I/O';

