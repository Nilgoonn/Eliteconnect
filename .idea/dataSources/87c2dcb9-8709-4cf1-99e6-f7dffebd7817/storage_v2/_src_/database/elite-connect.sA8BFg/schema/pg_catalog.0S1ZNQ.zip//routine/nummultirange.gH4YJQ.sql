create function nummultirange("$1" numrange) returns nummultirange
    language internal
as
$$ multirange_constructor0 $$;

comment on function nummultirange(numrange) is 'nummultirange constructor';

