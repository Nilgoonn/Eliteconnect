create function multirange_contains_elem(anymultirange, anyelement) returns boolean
    language internal
as
$$ multirange_contains_elem $$;

comment on function multirange_contains_elem(anymultirange, anyelement) is 'implementation of @> operator';

