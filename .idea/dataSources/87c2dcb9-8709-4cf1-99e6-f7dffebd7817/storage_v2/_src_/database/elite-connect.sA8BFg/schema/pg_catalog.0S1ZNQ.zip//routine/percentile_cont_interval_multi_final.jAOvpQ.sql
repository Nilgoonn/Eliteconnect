create function percentile_cont_interval_multi_final(internal, double precision[]) returns interval[]
    language internal
as
$$ percentile_cont_interval_multi_final $$;

comment on function percentile_cont_interval_multi_final(internal, _float8) is 'aggregate final function';

