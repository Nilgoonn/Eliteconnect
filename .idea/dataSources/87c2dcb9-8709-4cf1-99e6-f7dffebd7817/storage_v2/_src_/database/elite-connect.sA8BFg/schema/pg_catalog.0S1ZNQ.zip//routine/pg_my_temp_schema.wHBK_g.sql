create function pg_my_temp_schema() returns oid
    language internal
as
$$ pg_my_temp_schema $$;

comment on function pg_my_temp_schema() is 'get OID of current session''s temp schema, if any';

