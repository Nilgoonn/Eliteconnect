create function pg_log_backend_memory_contexts(integer) returns boolean
    language internal
as
$$ pg_log_backend_memory_contexts $$;

comment on function pg_log_backend_memory_contexts(int4) is 'log memory contexts of the specified backend';

