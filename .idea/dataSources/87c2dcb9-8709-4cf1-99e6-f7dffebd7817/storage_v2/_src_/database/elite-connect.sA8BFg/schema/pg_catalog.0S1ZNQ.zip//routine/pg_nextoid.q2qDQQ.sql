create function pg_nextoid(regclass, name, regclass) returns oid
    language internal
as
$$ pg_nextoid $$;

comment on function pg_nextoid(regclass, name, regclass) is 'return the next oid for a system table';

