create function pg_prepared_statement(OUT name text, OUT statement text, OUT prepare_time timestamp with time zone, OUT parameter_types regtype[], OUT result_types regtype[], OUT from_sql boolean, OUT generic_plans bigint, OUT custom_plans bigint) returns SETOF record
    language internal
as
$$ pg_prepared_statement $$;

comment on function pg_prepared_statement(out text, out text, out timestamptz, out _regtype, out _regtype, out bool, out int8, out int8) is 'get the prepared statements for this session';

