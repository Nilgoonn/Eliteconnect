create function pg_logical_emit_message(transactional boolean, prefix text, message bytea, flush boolean DEFAULT false) returns pg_lsn
    language internal
as
$$ pg_logical_emit_message_bytea $$;

comment on function pg_logical_emit_message(bool, text, bytea, bool) is 'emit a binary logical decoding message';

