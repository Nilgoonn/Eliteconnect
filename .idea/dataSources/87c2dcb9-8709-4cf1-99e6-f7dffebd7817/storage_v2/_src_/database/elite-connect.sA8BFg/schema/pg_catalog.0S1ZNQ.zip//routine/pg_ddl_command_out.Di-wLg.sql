create function pg_ddl_command_out(pg_ddl_command) returns cstring
    language internal
as
$$ pg_ddl_command_out $$;

comment on function pg_ddl_command_out(pg_ddl_command) is 'I/O';

