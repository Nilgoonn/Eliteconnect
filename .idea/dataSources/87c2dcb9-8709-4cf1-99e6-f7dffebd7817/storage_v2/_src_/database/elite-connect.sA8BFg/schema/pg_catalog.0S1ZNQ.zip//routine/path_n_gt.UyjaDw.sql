create function path_n_gt(path, path) returns boolean
    language internal
as
$$ path_n_gt $$;

comment on function path_n_gt(path, path) is 'implementation of > operator';

