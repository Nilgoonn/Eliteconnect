create function oidvectorlt(oidvector, oidvector) returns boolean
    language internal
as
$$ oidvectorlt $$;

comment on function oidvectorlt(oidvector, oidvector) is 'implementation of < operator';

