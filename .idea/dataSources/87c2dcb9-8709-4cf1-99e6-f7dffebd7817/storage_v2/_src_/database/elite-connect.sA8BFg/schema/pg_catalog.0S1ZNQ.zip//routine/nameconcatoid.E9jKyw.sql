create function nameconcatoid(name, oid) returns name
    language internal
as
$$ nameconcatoid $$;

comment on function nameconcatoid(name, oid) is 'concatenate name and oid';

