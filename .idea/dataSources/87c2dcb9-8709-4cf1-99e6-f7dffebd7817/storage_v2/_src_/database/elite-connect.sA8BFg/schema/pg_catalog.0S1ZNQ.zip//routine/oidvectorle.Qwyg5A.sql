create function oidvectorle(oidvector, oidvector) returns boolean
    language internal
as
$$ oidvectorle $$;

comment on function oidvectorle(oidvector, oidvector) is 'implementation of <= operator';

