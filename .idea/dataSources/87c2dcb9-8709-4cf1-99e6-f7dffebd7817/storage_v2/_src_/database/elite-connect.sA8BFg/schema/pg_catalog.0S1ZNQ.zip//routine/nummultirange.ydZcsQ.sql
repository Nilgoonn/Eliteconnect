create function nummultirange() returns nummultirange
    language internal
as
$$ multirange_constructor0 $$;

comment on function nummultirange() is 'nummultirange constructor';

