create function pg_read_file(text, bigint, bigint, boolean) returns text
    language internal
as
$$ pg_read_file_off_len_missing $$;

comment on function pg_read_file(text, bool) is 'read text from a file';

