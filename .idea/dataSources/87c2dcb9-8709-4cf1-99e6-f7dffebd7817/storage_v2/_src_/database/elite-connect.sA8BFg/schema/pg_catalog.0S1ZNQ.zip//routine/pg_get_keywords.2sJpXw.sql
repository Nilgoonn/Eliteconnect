create function pg_get_keywords(OUT word text, OUT catcode "char", OUT barelabel boolean, OUT catdesc text, OUT baredesc text) returns SETOF record
    language internal
as
$$ pg_get_keywords $$;

comment on function pg_get_keywords(out text, out "char", out bool, out text, out text) is 'list of SQL keywords';

