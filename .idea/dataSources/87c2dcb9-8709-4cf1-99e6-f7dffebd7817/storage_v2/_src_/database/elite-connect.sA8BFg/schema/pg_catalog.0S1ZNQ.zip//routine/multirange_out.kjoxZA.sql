create function multirange_out(anymultirange) returns cstring
    language internal
as
$$ multirange_out $$;

comment on function multirange_out(anymultirange) is 'I/O';

