create function oidlarger(oid, oid) returns oid
    language internal
as
$$ oidlarger $$;

comment on function oidlarger(oid, oid) is 'larger of two';

