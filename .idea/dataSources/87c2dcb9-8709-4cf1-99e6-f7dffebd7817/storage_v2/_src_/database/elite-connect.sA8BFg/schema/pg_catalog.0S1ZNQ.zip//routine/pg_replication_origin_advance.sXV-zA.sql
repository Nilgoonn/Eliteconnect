create function pg_replication_origin_advance(text, pg_lsn) returns void
    language internal
as
$$ pg_replication_origin_advance $$;

comment on function pg_replication_origin_advance(text, pg_lsn) is 'advance replication origin to specific location';

