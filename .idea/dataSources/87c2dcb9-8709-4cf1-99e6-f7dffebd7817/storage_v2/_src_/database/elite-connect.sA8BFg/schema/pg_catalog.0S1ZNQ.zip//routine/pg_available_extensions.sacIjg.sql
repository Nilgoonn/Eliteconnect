create function pg_available_extensions(OUT name name, OUT default_version text, OUT comment text) returns SETOF record
    language internal
as
$$ pg_available_extensions $$;

comment on function pg_available_extensions(out name, out text, out text) is 'list available extensions';

