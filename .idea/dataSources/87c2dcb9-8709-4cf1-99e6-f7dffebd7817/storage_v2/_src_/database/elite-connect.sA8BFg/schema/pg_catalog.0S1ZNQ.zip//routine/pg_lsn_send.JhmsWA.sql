create function pg_lsn_send(pg_lsn) returns bytea
    language internal
as
$$ pg_lsn_send $$;

comment on function pg_lsn_send(pg_lsn) is 'I/O';

