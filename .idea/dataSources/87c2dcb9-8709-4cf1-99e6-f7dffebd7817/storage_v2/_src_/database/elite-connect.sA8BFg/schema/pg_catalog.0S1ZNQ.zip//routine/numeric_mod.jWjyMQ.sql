create function numeric_mod(numeric, numeric) returns numeric
    language internal
as
$$ numeric_mod $$;

comment on function numeric_mod(numeric, numeric) is 'implementation of % operator';

