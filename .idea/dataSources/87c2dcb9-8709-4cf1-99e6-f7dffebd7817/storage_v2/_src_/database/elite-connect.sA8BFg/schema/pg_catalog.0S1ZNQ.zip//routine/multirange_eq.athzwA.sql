create function multirange_eq(anymultirange, anymultirange) returns boolean
    language internal
as
$$ multirange_eq $$;

comment on function multirange_eq(anymultirange, anymultirange) is 'implementation of = operator';

