create function pg_reload_conf() returns boolean
    language internal
as
$$ pg_reload_conf $$;

comment on function pg_reload_conf() is 'reload configuration files';

