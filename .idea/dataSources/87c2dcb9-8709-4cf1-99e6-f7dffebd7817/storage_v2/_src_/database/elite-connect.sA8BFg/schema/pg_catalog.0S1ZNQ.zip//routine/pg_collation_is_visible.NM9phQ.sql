create function pg_collation_is_visible(oid) returns boolean
    language internal
as
$$ pg_collation_is_visible $$;

comment on function pg_collation_is_visible(oid) is 'is collation visible in search path?';

