create function numeric_inc(numeric) returns numeric
    language internal
as
$$ numeric_inc $$;

comment on function numeric_inc(numeric) is 'increment by one';

