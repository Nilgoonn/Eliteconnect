create function pg_last_committed_xact(OUT xid xid, OUT "timestamp" timestamp with time zone, OUT roident oid) returns record
    language internal
as
$$ pg_last_committed_xact $$;

comment on function pg_last_committed_xact(out xid, out timestamptz, out oid) is 'get transaction Id, commit timestamp and replication origin of latest transaction commit';

