create function pg_ls_dir(text) returns SETOF text
    language internal
as
$$ pg_ls_dir_1arg $$;

comment on function pg_ls_dir(text) is 'list all files in a directory';

