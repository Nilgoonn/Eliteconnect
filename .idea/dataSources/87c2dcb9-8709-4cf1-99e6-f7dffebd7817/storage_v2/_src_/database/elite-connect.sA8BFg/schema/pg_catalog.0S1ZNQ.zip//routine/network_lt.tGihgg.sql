create function network_lt(inet, inet) returns boolean
    language internal
as
$$ network_lt $$;

comment on function network_lt(inet, inet) is 'implementation of < operator';

