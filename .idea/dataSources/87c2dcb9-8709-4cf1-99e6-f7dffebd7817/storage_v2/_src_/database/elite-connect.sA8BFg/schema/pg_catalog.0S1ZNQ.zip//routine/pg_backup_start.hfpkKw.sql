create function pg_backup_start(label text, fast boolean DEFAULT false) returns pg_lsn
    language internal
as
$$ pg_backup_start $$;

comment on function pg_backup_start(text, bool) is 'prepare for taking an online backup';

