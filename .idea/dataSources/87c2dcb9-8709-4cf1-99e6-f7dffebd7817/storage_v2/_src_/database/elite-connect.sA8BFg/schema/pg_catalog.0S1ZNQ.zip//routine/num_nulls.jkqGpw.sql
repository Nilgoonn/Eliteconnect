create function num_nulls(VARIADIC "any") returns integer
    language internal
as
$$ pg_num_nulls $$;

comment on function num_nulls(any) is 'count the number of NULL arguments';

