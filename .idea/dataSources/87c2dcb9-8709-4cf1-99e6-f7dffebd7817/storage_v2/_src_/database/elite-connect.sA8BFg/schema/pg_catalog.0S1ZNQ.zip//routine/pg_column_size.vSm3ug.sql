create function pg_column_size("any") returns integer
    language internal
as
$$ pg_column_size $$;

comment on function pg_column_size(any) is 'bytes required to store the value, perhaps with compression';

