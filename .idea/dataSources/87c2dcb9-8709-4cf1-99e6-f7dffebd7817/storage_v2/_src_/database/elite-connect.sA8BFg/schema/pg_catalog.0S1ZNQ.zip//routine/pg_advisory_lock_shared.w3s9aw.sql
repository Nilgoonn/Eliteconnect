create function pg_advisory_lock_shared(bigint) returns void
    language internal
as
$$ pg_advisory_lock_shared_int8 $$;

comment on function pg_advisory_lock_shared(int8) is 'obtain shared advisory lock';

