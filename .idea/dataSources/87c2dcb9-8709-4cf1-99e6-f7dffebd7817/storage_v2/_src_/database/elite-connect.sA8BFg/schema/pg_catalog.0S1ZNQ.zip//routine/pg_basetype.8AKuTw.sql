create function pg_basetype(regtype) returns regtype
    language internal
as
$$ pg_basetype $$;

comment on function pg_basetype(regtype) is 'base type of a domain type';

