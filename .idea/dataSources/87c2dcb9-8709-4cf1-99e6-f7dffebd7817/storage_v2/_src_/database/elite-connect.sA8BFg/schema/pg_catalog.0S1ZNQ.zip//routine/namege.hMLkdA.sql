create function namege(name, name) returns boolean
    language internal
as
$$ namege $$;

comment on function namege(name, name) is 'implementation of >= operator';

