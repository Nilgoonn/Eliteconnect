create function namegt(name, name) returns boolean
    language internal
as
$$ namegt $$;

comment on function namegt(name, name) is 'implementation of > operator';

