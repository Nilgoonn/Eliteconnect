create function pg_ls_logdir(OUT name text, OUT size bigint, OUT modification timestamp with time zone) returns SETOF record
    language internal
as
$$ pg_ls_logdir $$;

comment on function pg_ls_logdir(out text, out int8, out timestamptz) is 'list files in the log directory';

