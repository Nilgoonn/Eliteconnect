create function network_gt(inet, inet) returns boolean
    language internal
as
$$ network_gt $$;

comment on function network_gt(inet, inet) is 'implementation of > operator';

