create function pg_ndistinct_out(pg_ndistinct) returns cstring
    language internal
as
$$ pg_ndistinct_out $$;

comment on function pg_ndistinct_out(pg_ndistinct) is 'I/O';

