create function percent_rank_final(internal, VARIADIC "any") returns double precision
    language internal
as
$$ hypothetical_percent_rank_final $$;

comment on function percent_rank_final(internal, any) is 'aggregate final function';

