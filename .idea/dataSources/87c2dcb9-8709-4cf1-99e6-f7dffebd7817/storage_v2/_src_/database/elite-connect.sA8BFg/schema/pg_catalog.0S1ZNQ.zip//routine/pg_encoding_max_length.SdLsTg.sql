create function pg_encoding_max_length(integer) returns integer
    language internal
as
$$ pg_encoding_max_length_sql $$;

comment on function pg_encoding_max_length(int4) is 'maximum octet length of a character in given encoding';

