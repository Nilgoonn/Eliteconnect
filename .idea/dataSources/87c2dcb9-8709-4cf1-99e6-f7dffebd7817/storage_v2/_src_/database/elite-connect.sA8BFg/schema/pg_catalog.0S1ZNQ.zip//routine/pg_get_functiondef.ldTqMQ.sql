create function pg_get_functiondef(oid) returns text
    language internal
as
$$ pg_get_functiondef $$;

comment on function pg_get_functiondef(oid) is 'definition of a function';

