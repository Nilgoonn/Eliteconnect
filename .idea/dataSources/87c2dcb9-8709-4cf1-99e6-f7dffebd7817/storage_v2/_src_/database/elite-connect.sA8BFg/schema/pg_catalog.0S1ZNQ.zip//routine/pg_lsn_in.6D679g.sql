create function pg_lsn_in(cstring) returns pg_lsn
    language internal
as
$$ pg_lsn_in $$;

comment on function pg_lsn_in(cstring) is 'I/O';

