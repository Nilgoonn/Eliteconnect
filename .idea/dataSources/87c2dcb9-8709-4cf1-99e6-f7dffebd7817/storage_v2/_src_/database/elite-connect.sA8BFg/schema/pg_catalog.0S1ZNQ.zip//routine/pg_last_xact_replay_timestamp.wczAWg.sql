create function pg_last_xact_replay_timestamp() returns timestamp with time zone
    language internal
as
$$ pg_last_xact_replay_timestamp $$;

comment on function pg_last_xact_replay_timestamp() is 'timestamp of last replay xact';

