create function pg_get_publication_tables(VARIADIC pubname text[], OUT pubid oid, OUT relid oid, OUT attrs int2vector, OUT qual pg_node_tree) returns SETOF record
    language internal
as
$$ pg_get_publication_tables $$;

comment on function pg_get_publication_tables(_text, out oid, out oid, out int2vector, out pg_node_tree) is 'get information of the tables that are part of the specified publications';

