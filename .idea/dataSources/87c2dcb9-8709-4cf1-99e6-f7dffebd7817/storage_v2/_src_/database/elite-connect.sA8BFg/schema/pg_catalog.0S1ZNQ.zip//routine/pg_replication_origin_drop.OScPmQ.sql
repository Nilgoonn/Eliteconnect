create function pg_replication_origin_drop(text) returns void
    language internal
as
$$ pg_replication_origin_drop $$;

comment on function pg_replication_origin_drop(text) is 'drop replication origin identified by its name';

