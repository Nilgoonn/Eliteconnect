create function nameicnlike(name, text) returns boolean
    language internal
as
$$ nameicnlike $$;

comment on function nameicnlike(name, text) is 'implementation of !~~* operator';

