create function on_pl(point, line) returns boolean
    language internal
as
$$ on_pl $$;

comment on function on_pl(point, line) is 'implementation of <@ operator';

