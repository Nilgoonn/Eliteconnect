create function numeric_sub(numeric, numeric) returns numeric
    language internal
as
$$ numeric_sub $$;

comment on function numeric_sub(numeric, numeric) is 'implementation of - operator';

