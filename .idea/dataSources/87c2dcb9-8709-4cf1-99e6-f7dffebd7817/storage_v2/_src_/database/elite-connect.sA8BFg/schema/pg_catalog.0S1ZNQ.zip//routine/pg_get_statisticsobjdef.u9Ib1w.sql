create function pg_get_statisticsobjdef(oid) returns text
    language internal
as
$$ pg_get_statisticsobjdef $$;

comment on function pg_get_statisticsobjdef(oid) is 'extended statistics object description';

