create function pg_listening_channels() returns SETOF text
    language internal
as
$$ pg_listening_channels $$;

comment on function pg_listening_channels() is 'get the channels that the current backend listens to';

