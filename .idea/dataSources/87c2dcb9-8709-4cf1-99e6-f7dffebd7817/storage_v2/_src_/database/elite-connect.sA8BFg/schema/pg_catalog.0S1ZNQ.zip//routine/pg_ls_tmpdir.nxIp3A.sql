create function pg_ls_tmpdir(OUT name text, OUT size bigint, OUT modification timestamp with time zone) returns SETOF record
    language internal
as
$$ pg_ls_tmpdir_noargs $$;

comment on function pg_ls_tmpdir(oid, out text, out int8, out timestamptz) is 'list files in the pgsql_tmp directory';

