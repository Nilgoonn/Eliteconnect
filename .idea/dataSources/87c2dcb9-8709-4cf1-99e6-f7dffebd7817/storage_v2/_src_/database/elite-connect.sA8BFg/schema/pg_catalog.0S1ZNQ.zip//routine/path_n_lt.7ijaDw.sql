create function path_n_lt(path, path) returns boolean
    language internal
as
$$ path_n_lt $$;

comment on function path_n_lt(path, path) is 'implementation of < operator';

