create function pg_log_standby_snapshot() returns pg_lsn
    language internal
as
$$ pg_log_standby_snapshot $$;

comment on function pg_log_standby_snapshot() is 'log details of the current snapshot to WAL';

