create function network_sup(inet, inet) returns boolean
    language internal
as
$$ network_sup $$;

comment on function network_sup(inet, inet) is 'implementation of >> operator';

