create function pg_replication_origin_session_is_setup() returns boolean
    language internal
as
$$ pg_replication_origin_session_is_setup $$;

comment on function pg_replication_origin_session_is_setup() is 'is a replication origin configured in this session';

