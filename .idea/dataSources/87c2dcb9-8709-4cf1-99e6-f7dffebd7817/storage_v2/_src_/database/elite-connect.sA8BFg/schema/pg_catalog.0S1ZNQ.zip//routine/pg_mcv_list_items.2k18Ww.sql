create function pg_mcv_list_items(mcv_list pg_mcv_list, OUT index integer, OUT "values" text[], OUT nulls boolean[], OUT frequency double precision, OUT base_frequency double precision) returns SETOF record
    language internal
as
$$ pg_stats_ext_mcvlist_items $$;

comment on function pg_mcv_list_items(pg_mcv_list, out int4, out _text, out _bool, out float8, out float8) is 'details about MCV list items';

