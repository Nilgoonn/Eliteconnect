create function namene(name, name) returns boolean
    language internal
as
$$ namene $$;

comment on function namene(name, name) is 'implementation of <> operator';

