create function pg_get_expr(pg_node_tree, oid) returns text
    language internal
as
$$ pg_get_expr $$;

comment on function pg_get_expr(pg_node_tree, oid, bool) is 'deparse an encoded expression with pretty-print option';

