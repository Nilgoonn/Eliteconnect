create function pg_mcv_list_recv(internal) returns pg_mcv_list
    language internal
as
$$ pg_mcv_list_recv $$;

comment on function pg_mcv_list_recv(internal) is 'I/O';

