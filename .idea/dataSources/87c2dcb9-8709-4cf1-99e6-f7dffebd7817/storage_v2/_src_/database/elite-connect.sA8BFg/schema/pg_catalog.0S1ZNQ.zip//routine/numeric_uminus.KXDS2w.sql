create function numeric_uminus(numeric) returns numeric
    language internal
as
$$ numeric_uminus $$;

comment on function numeric_uminus(numeric) is 'implementation of - operator';

