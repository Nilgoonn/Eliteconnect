create function pclose(path) returns path
    language internal
as
$$ path_close $$;

comment on function pclose(path) is 'close path';

