create function numeric(money) returns numeric
    language internal
as
$$ cash_numeric $$;

comment on function numeric(float8) is 'convert float8 to numeric';

