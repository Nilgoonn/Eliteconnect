create function pg_get_multixact_members(multixid xid, OUT xid xid, OUT mode text) returns SETOF record
    language internal
as
$$ pg_get_multixact_members $$;

comment on function pg_get_multixact_members(xid, out xid, out text) is 'view members of a multixactid';

