create function pg_last_wal_receive_lsn() returns pg_lsn
    language internal
as
$$ pg_last_wal_receive_lsn $$;

comment on function pg_last_wal_receive_lsn() is 'current wal flush location';

