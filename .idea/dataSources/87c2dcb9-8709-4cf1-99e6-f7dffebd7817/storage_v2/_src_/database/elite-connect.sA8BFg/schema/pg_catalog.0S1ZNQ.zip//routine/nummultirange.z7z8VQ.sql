create function nummultirange("$1" _numrange) returns nummultirange
    language internal
as
$$ multirange_constructor0 $$;

comment on function nummultirange(_numrange) is 'nummultirange constructor';

