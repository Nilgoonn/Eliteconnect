create function pg_notification_queue_usage() returns double precision
    language internal
as
$$ pg_notification_queue_usage $$;

comment on function pg_notification_queue_usage() is 'get the fraction of the asynchronous notification queue currently in use';

