create function oidvectorne(oidvector, oidvector) returns boolean
    language internal
as
$$ oidvectorne $$;

comment on function oidvectorne(oidvector, oidvector) is 'implementation of <> operator';

