create function neqjoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$ neqjoinsel $$;

comment on function neqjoinsel(internal, oid, internal, int2, internal) is 'join selectivity of <> and related operators';

