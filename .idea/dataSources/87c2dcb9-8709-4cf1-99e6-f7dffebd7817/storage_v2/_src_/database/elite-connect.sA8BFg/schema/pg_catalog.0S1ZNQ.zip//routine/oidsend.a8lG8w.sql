create function oidsend(oid) returns bytea
    language internal
as
$$ oidsend $$;

comment on function oidsend(oid) is 'I/O';

