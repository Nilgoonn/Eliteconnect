create function pg_database_size(name) returns bigint
    language internal
as
$$ pg_database_size_name $$;

comment on function pg_database_size(oid) is 'total disk space usage for the specified database';

