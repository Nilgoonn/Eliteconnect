create function numeric_power(numeric, numeric) returns numeric
    language internal
as
$$ numeric_power $$;

comment on function numeric_power(numeric, numeric) is 'implementation of ^ operator';

