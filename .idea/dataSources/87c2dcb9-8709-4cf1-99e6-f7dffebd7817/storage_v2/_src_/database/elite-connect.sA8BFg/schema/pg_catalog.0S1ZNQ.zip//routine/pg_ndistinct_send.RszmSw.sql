create function pg_ndistinct_send(pg_ndistinct) returns bytea
    language internal
as
$$ pg_ndistinct_send $$;

comment on function pg_ndistinct_send(pg_ndistinct) is 'I/O';

