create function pg_isolation_test_session_is_blocked(integer, integer[]) returns boolean
    language internal
as
$$ pg_isolation_test_session_is_blocked $$;

comment on function pg_isolation_test_session_is_blocked(int4, _int4) is 'isolationtester support function';

