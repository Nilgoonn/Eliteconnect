create function on_pb(point, box) returns boolean
    language internal
as
$$ on_pb $$;

comment on function on_pb(point, box) is 'implementation of <@ operator';

