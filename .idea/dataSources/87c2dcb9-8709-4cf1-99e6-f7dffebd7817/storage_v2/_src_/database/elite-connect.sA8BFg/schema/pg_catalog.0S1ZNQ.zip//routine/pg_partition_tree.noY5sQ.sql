create function pg_partition_tree(rootrelid regclass, OUT relid regclass, OUT parentrelid regclass, OUT isleaf boolean, OUT level integer) returns SETOF record
    language internal
as
$$ pg_partition_tree $$;

comment on function pg_partition_tree(regclass, out regclass, out regclass, out bool, out int4) is 'view partition tree tables';

