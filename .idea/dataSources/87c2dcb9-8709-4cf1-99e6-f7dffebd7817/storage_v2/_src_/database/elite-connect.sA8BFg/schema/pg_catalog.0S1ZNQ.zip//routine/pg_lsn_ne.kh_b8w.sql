create function pg_lsn_ne(pg_lsn, pg_lsn) returns boolean
    language internal
as
$$ pg_lsn_ne $$;

comment on function pg_lsn_ne(pg_lsn, pg_lsn) is 'implementation of <> operator';

