create function pg_control_init(OUT max_data_alignment integer, OUT database_block_size integer, OUT blocks_per_segment integer, OUT wal_block_size integer, OUT bytes_per_wal_segment integer, OUT max_identifier_length integer, OUT max_index_columns integer, OUT max_toast_chunk_size integer, OUT large_object_chunk_size integer, OUT float8_pass_by_value boolean, OUT data_page_checksum_version integer) returns record
    language internal
as
$$ pg_control_init $$;

comment on function pg_control_init(out int4, out int4, out int4, out int4, out int4, out int4, out int4, out int4, out int4, out bool, out int4) is 'pg_controldata init state information as a function';

