create function numeric_avg_combine(internal, internal) returns internal
    language internal
as
$$ numeric_avg_combine $$;

comment on function numeric_avg_combine(internal, internal) is 'aggregate combine function';

