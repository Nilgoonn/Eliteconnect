create function _pg_interval_type(typid oid, mod integer) returns text
    language sql
as
$$
    begin
-- missing source code
end;
$$;

