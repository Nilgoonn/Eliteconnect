create function pg_get_ruledef(oid) returns text
    language internal
as
$$ pg_get_ruledef $$;

comment on function pg_get_ruledef(oid) is 'source text of a rule';

