create function pg_lsn_cmp(pg_lsn, pg_lsn) returns integer
    language internal
as
$$ pg_lsn_cmp $$;

comment on function pg_lsn_cmp(pg_lsn, pg_lsn) is 'less-equal-greater';

