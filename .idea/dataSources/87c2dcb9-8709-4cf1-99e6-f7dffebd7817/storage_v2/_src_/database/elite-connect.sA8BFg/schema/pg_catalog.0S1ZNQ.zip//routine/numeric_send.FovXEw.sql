create function numeric_send(numeric) returns bytea
    language internal
as
$$ numeric_send $$;

comment on function numeric_send(numeric) is 'I/O';

