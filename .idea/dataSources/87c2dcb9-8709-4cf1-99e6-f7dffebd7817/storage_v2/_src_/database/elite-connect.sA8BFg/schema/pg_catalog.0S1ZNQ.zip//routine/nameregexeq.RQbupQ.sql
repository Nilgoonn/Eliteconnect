create function nameregexeq(name, text) returns boolean
    language internal
as
$$ nameregexeq $$;

comment on function nameregexeq(name, text) is 'implementation of ~ operator';

