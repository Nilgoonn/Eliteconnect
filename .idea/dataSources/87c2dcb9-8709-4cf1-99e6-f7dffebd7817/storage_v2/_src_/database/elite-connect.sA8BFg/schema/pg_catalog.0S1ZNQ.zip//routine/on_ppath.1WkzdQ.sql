create function on_ppath(point, path) returns boolean
    language internal
as
$$ on_ppath $$;

comment on function on_ppath(point, path) is 'implementation of <@ operator';

