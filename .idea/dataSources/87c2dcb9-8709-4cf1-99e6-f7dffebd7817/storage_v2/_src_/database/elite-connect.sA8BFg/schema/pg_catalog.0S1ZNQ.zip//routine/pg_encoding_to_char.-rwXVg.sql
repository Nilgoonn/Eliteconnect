create function pg_encoding_to_char(integer) returns name
    language internal
as
$$ PG_encoding_to_char $$;

comment on function pg_encoding_to_char(int4) is 'convert encoding id to encoding name';

