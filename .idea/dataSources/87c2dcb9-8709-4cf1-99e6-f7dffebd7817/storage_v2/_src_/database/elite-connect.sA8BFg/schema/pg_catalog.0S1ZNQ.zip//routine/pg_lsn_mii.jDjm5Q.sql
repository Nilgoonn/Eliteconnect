create function pg_lsn_mii(pg_lsn, numeric) returns pg_lsn
    language internal
as
$$ pg_lsn_mii $$;

comment on function pg_lsn_mii(pg_lsn, numeric) is 'implementation of - operator';

