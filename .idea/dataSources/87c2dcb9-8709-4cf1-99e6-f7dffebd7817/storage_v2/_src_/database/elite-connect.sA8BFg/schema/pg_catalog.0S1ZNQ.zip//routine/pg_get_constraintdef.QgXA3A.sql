create function pg_get_constraintdef(oid) returns text
    language internal
as
$$ pg_get_constraintdef $$;

comment on function pg_get_constraintdef(oid, bool) is 'constraint description with pretty-print option';

