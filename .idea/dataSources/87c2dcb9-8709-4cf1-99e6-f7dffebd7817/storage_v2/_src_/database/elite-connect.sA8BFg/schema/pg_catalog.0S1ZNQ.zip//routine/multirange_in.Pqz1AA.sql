create function multirange_in(cstring, oid, integer) returns anymultirange
    language internal
as
$$ multirange_in $$;

comment on function multirange_in(cstring, oid, int4) is 'I/O';

