create function multirange_ge(anymultirange, anymultirange) returns boolean
    language internal
as
$$ multirange_ge $$;

comment on function multirange_ge(anymultirange, anymultirange) is 'implementation of >= operator';

