create function namele(name, name) returns boolean
    language internal
as
$$ namele $$;

comment on function namele(name, name) is 'implementation of <= operator';

