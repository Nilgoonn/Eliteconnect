create function pg_lsn_ge(pg_lsn, pg_lsn) returns boolean
    language internal
as
$$ pg_lsn_ge $$;

comment on function pg_lsn_ge(pg_lsn, pg_lsn) is 'implementation of >= operator';

