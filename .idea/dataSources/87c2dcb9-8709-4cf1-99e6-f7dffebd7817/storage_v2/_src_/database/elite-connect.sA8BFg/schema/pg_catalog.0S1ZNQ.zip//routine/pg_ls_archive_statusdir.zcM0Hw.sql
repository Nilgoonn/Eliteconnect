create function pg_ls_archive_statusdir(OUT name text, OUT size bigint, OUT modification timestamp with time zone) returns SETOF record
    language internal
as
$$ pg_ls_archive_statusdir $$;

comment on function pg_ls_archive_statusdir(out text, out int8, out timestamptz) is 'list of files in the archive_status directory';

