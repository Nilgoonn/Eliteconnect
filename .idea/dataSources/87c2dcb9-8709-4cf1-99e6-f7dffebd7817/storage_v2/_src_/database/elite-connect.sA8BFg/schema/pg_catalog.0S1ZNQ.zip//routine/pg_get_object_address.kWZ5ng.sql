create function pg_get_object_address(type text, object_names text[], object_args text[], OUT classid oid, OUT objid oid, OUT objsubid integer) returns record
    language internal
as
$$ pg_get_object_address $$;

comment on function pg_get_object_address(text, _text, _text, out oid, out oid, out int4) is 'get OID-based object address from name/args arrays';

