create function nameout(name) returns cstring
    language internal
as
$$ nameout $$;

comment on function nameout(name) is 'I/O';

