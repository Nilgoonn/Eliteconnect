create function oidout(oid) returns cstring
    language internal
as
$$ oidout $$;

comment on function oidout(oid) is 'I/O';

