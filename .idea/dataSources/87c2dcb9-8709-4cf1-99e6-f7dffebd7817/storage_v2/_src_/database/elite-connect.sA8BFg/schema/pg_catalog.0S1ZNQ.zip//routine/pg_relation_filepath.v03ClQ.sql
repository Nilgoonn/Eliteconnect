create function pg_relation_filepath(regclass) returns text
    language internal
as
$$ pg_relation_filepath $$;

comment on function pg_relation_filepath(regclass) is 'file path of relation';

