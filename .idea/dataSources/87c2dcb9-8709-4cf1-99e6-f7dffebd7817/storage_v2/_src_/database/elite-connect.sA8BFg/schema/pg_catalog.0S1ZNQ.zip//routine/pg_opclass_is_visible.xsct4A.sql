create function pg_opclass_is_visible(oid) returns boolean
    language internal
as
$$ pg_opclass_is_visible $$;

comment on function pg_opclass_is_visible(oid) is 'is opclass visible in search path?';

