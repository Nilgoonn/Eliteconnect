create function pg_replication_origin_session_reset() returns void
    language internal
as
$$ pg_replication_origin_session_reset $$;

comment on function pg_replication_origin_session_reset() is 'teardown configured replication progress tracking';

